package com.bookmate.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Sky = Color(0xFFEAF5FF)
private val Blue = Color(0xFF4A9FE8)
private val Navy = Color(0xFF17324D)
private val PaleBlue = Color(0xFFD5EBFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = BookDatabase.get(this).dao()
        setContent { BookMateApp(BookMateViewModel(dao)) }
    }
}

class BookMateViewModel(private val dao: BookDao) : ViewModel() {
    val books = dao.observeBooks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sessions = dao.observeSessions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addBook(title: String, author: String, genre: String, pages: Int, fiction: Boolean) {
        viewModelScope.launch {
            if (title.isNotBlank() && pages > 0) dao.addBook(
                Book(title = title.trim(), author = author.trim(), genre = genre, totalPages = pages, isFiction = fiction)
            )
        }
    }

    fun updateProgress(book: Book, page: Int, minutes: Int) {
        viewModelScope.launch {
            val safePage = page.coerceIn(0, book.totalPages)
            val updated = if (book.isFiction || book.secondPassPage > 0) book.copy(secondPassPage = safePage)
                          else book.copy(firstPassPage = safePage)
            dao.updateBook(updated)
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
            dao.addSession(ReadingSession(bookId = book.id, pagesRead = 0, minutes = minutes.coerceAtLeast(0), dateKey = today))
        }
    }

    fun saveNote(bookId: Long, page: Int, body: String) {
        viewModelScope.launch { if (body.isNotBlank()) dao.addNote(ReadingNote(bookId = bookId, page = page, body = body.trim())) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookMateApp(vm: BookMateViewModel) {
    val books by vm.books.collectAsState()
    val sessions by vm.sessions.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Book?>(null) }
    var dailyGoal by remember { mutableIntStateOf(20) }
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val minutesToday = sessions.filter { it.dateKey == today }.sumOf { it.minutes }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, onPrimary = Color.White, secondary = Navy,
            background = Sky, surface = Color.White, onSurface = Navy
        )
    ) {
        Scaffold(
            containerColor = Sky,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("BookMate", fontWeight = FontWeight.Bold, color = Navy)
                            Text("Your personal intellectual mentor", style = MaterialTheme.typography.labelSmall, color = Navy.copy(alpha = .7f))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Sky)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.AutoStories, null) }, label = { Text("Library") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.CheckCircle, null) }, label = { Text("Today") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Notes, null) }, label = { Text("Journal") })
                }
            },
            floatingActionButton = {
                if (tab == 0) FloatingActionButton(onClick = { showAdd = true }, containerColor = Blue, contentColor = Color.White) {
                    Icon(Icons.Default.Add, "Add book")
                }
            }
        ) { padding ->
            when (tab) {
                0 -> LibraryScreen(books, Modifier.padding(padding), onSelect = { selected = it })
                1 -> TodayScreen(books, dailyGoal, minutesToday, Modifier.padding(padding), onGoal = { dailyGoal = it }, onSelect = { selected = it })
                else -> JournalScreen(books, Modifier.padding(padding))
            }
        }

        if (showAdd) AddBookDialog(onDismiss = { showAdd = false }, onAdd = { t,a,g,p,f -> vm.addBook(t,a,g,p,f); showAdd = false })
        selected?.let { book ->
            ProgressDialog(book, onDismiss = { selected = null }, onSave = { page, mins -> vm.updateProgress(book, page, mins); selected = null })
        }
    }
}

@Composable
fun MentorCard(title: String, message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Blue, fontWeight = FontWeight.Bold)
            Text(message, color = Navy, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun LibraryScreen(books: List<Book>, modifier: Modifier, onSelect: (Book) -> Unit) {
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(4.dp))
        MentorCard("A small promise, kept daily.", "Read with attention, not haste. Your future understanding is built one page at a time.")
        Text("Your library", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Navy)
        if (books.isEmpty()) {
            Text("Your shelf is waiting. Add the physical book you are reading to begin.", color = Navy.copy(alpha = .75f))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
            items(books, key = { it.id }) { book ->
                val page = if (book.isFiction) book.secondPassPage else book.firstPassPage
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(book) },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(book.title, fontWeight = FontWeight.Bold, color = Navy)
                        Text("${book.author.ifBlank { "Author not added" }} • ${book.genre}", color = Navy.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator(progress = { page.toFloat() / book.totalPages.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth(), color = Blue, trackColor = PaleBlue)
                        Text("$page / ${book.totalPages} pages • ${if (book.isFiction) "Story reading" else if (page >= book.totalPages) "First pass complete — restart for a careful second pass" else "First pass"}", style = MaterialTheme.typography.labelSmall, color = Navy)
                    }
                }
            }
        }
    }
}

@Composable
fun TodayScreen(books: List<Book>, goal: Int, minutes: Int, modifier: Modifier, onGoal: (Int) -> Unit, onSelect: (Book) -> Unit) {
    var goalText by remember(goal) { mutableStateOf(goal.toString()) }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        MentorCard("Today's reading", "Don't wait for the perfect mood. Choose a book, read a few pages, and let consistency do its work.")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Daily page target", color = Navy, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = goalText, onValueChange = { goalText = it.filter(Char::isDigit) }, label = { Text("Pages per day") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Button(onClick = { onGoal(goalText.toIntOrNull()?.coerceIn(1, 500) ?: 20) }) { Text("Save goal") }
                Text("Reading time recorded today: $minutes min", color = Navy)
            }
        }
        Text("Choose a book to update progress", color = Navy, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(books, key = { it.id }) { book ->
                OutlinedButton(onClick = { onSelect(book) }, modifier = Modifier.fillMaxWidth()) {
                    Text("${book.title} — update pages")
                }
            }
        }
    }
}

@Composable
fun JournalScreen(books: List<Book>, modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        MentorCard("Think beyond the page.", "After a reading session, write what you understood in your own words. A short, honest reflection is better than copied paragraphs.")
        Text("Your reading journal", color = Navy, fontWeight = FontWeight.Bold)
        Text("Notebook entries and book-linked notes are planned for the next build. For now, use this space as a reminder to record arguments, questions, evidence and connections in your physical notebook.", color = Navy)
    }
}

@Composable
fun AddBookDialog(onDismiss: () -> Unit, onAdd: (String, String, String, Int, Boolean) -> Unit) {
    var title by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("History") }
    var pages by remember { mutableStateOf("") }
    var fiction by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a physical book") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Book title") }, singleLine = true)
                OutlinedTextField(author, { author = it }, label = { Text("Author") }, singleLine = true)
                OutlinedTextField(pages, { pages = it.filter(Char::isDigit) }, label = { Text("Total pages") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Text("Genre")
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }) { Text(genre) }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        listOf("History", "Philosophy", "Islamic Studies", "Comparative Religion", "Academic / Non-fiction", "Biography", "Fiction", "Other").forEach {
                            DropdownMenuItem(text = { Text(it) }, onClick = { genre = it; expanded = false; if (it == "Fiction") fiction = true })
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = fiction, onCheckedChange = { fiction = it })
                    Text("This is fiction")
                }
            }
        },
        confirmButton = { Button(onClick = { onAdd(title, author, genre, pages.toIntOrNull() ?: 0, fiction) }, enabled = title.isNotBlank() && (pages.toIntOrNull() ?: 0) > 0) { Text("Add book") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ProgressDialog(book: Book, onDismiss: () -> Unit, onSave: (Int, Int) -> Unit) {
    val current = if (book.isFiction) book.secondPassPage else book.firstPassPage
    var page by remember { mutableStateOf(current.toString()) }
    var minutes by remember { mutableStateOf("20") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Update reading progress") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(book.title, fontWeight = FontWeight.Bold)
                Text("Enter the last page you completed.")
                OutlinedTextField(page, { page = it.filter(Char::isDigit) }, label = { Text("Current page") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit) }, label = { Text("Minutes read") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (!book.isFiction && current >= book.totalPages) Text("First pass complete. The next version will guide your careful second pass.", color = Blue)
            }
        },
        confirmButton = { Button(onClick = { onSave(page.toIntOrNull() ?: current, minutes.toIntOrNull() ?: 0) }) { Text("Save progress") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
