package com.bookmate.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "books")
data class Book(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String,
    val genre: String,
    val totalPages: Int,
    val firstPassPage: Int = 0,
    val secondPassPage: Int = 0,
    val isFiction: Boolean = false,
    val startedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class ReadingNote(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val page: Int,
    val body: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sessions")
data class ReadingSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val pagesRead: Int,
    val minutes: Int,
    val dateKey: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface BookDao {
    @Query("SELECT * FROM books ORDER BY startedAt DESC")
    fun observeBooks(): Flow<List<Book>>

    @Insert
    suspend fun addBook(book: Book): Long

    @Update
    suspend fun updateBook(book: Book)

    @Delete
    suspend fun deleteBook(book: Book)

    @Insert
    suspend fun addNote(note: ReadingNote)

    @Query("SELECT * FROM notes WHERE bookId = :bookId ORDER BY createdAt DESC")
    fun observeNotes(bookId: Long): Flow<List<ReadingNote>>

    @Insert
    suspend fun addSession(session: ReadingSession)

    @Query("SELECT * FROM sessions ORDER BY createdAt DESC LIMIT 100")
    fun observeSessions(): Flow<List<ReadingSession>>
}

@Database(entities = [Book::class, ReadingNote::class, ReadingSession::class], version = 1)
abstract class BookDatabase : RoomDatabase() {
    abstract fun dao(): BookDao

    companion object {
        @Volatile private var INSTANCE: BookDatabase? = null
        fun get(context: Context): BookDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    BookDatabase::class.java,
                    "bookmate.db"
                ).build().also { INSTANCE = it }
            }
    }
}
