# BookMate Android — Starter project

BookMate is a native Android starter project for tracking physical-book reading. The interface uses a light-blue and white theme.

## Included in this starter
- Native Android app project using Kotlin and Jetpack Compose.
- Local Room database for books, reading sessions and notes schema.
- Add physical books, genre and total page count.
- Separate stored first-pass and second-pass page fields in the data model.
- Daily page target setting (in-memory in this starter).
- Reading time session logging.
- Library, Today and Journal screens.

## Important limitations in this first native build
This is a starter source project, not a signed APK. It has not been built or tested on a device in this environment.
- The UI currently updates first-pass progress for non-fiction; the second-pass workflow and independent per-pass controls still need finishing.
- The Journal screen is a placeholder; note storage exists in the database but note-entry UI is not wired yet.
- The daily goal is currently held in screen state and resets when the app process is recreated.
- No AI mentor connection is included yet.
- No reminders, Hijri calendar feed, missed-day review, or app-blocking feature is enabled yet.
- App blocking must be implemented as a separate, transparent Android feature with explicit user-granted permissions and emergency bypass. This starter does not monitor or restrict other apps.

## Open in Android Studio
1. Install Android Studio (current stable version).
2. Choose **Open** and select this `BookMate_Android` folder.
3. Allow Gradle sync to finish. Android Studio may download the Android Gradle Plugin and dependencies.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press **Run**.

If Gradle sync reports that SDK 35 is missing, install Android SDK Platform 35 from Android Studio's SDK Manager.

## Data
Book data is stored locally in the app's Room database on the phone. Uninstalling the app normally removes its local data. A backup/export feature should be added before relying on this as the only copy of important notes.


## Build an APK online using GitHub Actions (no Android Studio required on your phone)
This project includes `.github/workflows/build-apk.yml`.
1. Upload the extracted project folder contents to a new GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build BookMate APK**, then choose **Run workflow**.
4. When the run completes, open it and download the `BookMate-debug-apk` artifact.
5. Extract the downloaded artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that browser or file manager.

This creates a debug APK for testing, not a Play Store release. The cloud build requires a GitHub account and internet access.
