# BookMate Android project

Fresh Android project using Android Gradle Plugin 8.7.3, Gradle 8.9 and JDK 17. The native Android app hosts the local BookMate reading interface in a WebView.

Build with `gradle --no-daemon assembleDebug` from this folder. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Includes local book registration, page progress, a daily page goal and an in-app notebook. Data is stored locally on the device. It does not yet include cloud sync, a real AI mentor, automatic Hijri calendar feeds or Android app blocking.
